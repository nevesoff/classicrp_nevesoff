"use strict";

let fraction = module.exports;

fraction.get_name = function(fraction) {
  switch(parseInt(fraction)) {
    case 0: fraction = "-"; break;
    case 1: fraction = "Los Santos City Hall"; break;
    case 2: fraction = "Los Santos Police Department"; break;
    case 3: fraction = "Los Santos County Sheriff"; break;
    case 4: fraction = "Los Santos Medical Service"; break;
    case 5: fraction = "United States Armed Forces"; break;
    case 6: fraction = "Los Santos Fire Department"; break;
    case 7: fraction = "Los Santos Educational Center"; break;
    case 8: fraction = "Federal Intelligence Bureau"; break;
    case 9: fraction = "San Andreas State Prison"; break;
    case 10: fraction = "Fleeca Public Deposit Bank"; break;
  }
  return fraction;
}

fraction.get_rang = function(fraction, fraction_rang) {
  switch(parseInt(fraction)) {
    case 0: {
      fraction_rang = "-";
    } break;
    case 1: {
      switch(parseInt(fraction_rang)) {
        case 1: fraction_rang = "Security Service Trainee"; break;
        case 2: fraction_rang = "Security Service Officer"; break;
        case 3: fraction_rang = "Security Service Head"; break;
        case 4: fraction_rang = "Procurator"; break;
        case 5: fraction_rang = "Secretary"; break;
        case 6: fraction_rang = "Deputy Mayor"; break;
        case 7: fraction_rang = "Mayor"; break;
        
      }
    } break;
    case 2: {
      switch(parseInt(fraction_rang)) {
        case 1: fraction_rang = "Police Trainee"; break;
        case 2: fraction_rang = "Police Officer I"; break;
        case 3: fraction_rang = "Police Officer II"; break;
        case 4: fraction_rang = "Detective I"; break;
        case 5: fraction_rang = "Detective II"; break;
        case 6: fraction_rang = "Sergeant I"; break;
        case 7: fraction_rang = "Sergeant II"; break;
        case 8: fraction_rang = "Lieutenant I"; break;
        case 9: fraction_rang = "Lieutenant II"; break;
        case 10: fraction_rang = "Captain I"; break;
        case 11: fraction_rang = "Captain II"; break;
        case 12: fraction_rang = "Captain III"; break;
        case 13: fraction_rang = "Division Head"; break;
        case 14: fraction_rang = "Assistant Chief"; break;
        case 15: fraction_rang = "Chief of Police"; break;
      }
    } break;
    case 3: {
      switch(parseInt(fraction_rang)) {
        case 1: fraction_rang = "Стажер"; break;
        case 2: fraction_rang = "Офицер"; break;
        case 3: fraction_rang = "Сержант"; break;
        case 4: fraction_rang = "Лейтенант"; break;
        case 5: fraction_rang = "Капитан"; break;
        case 6: fraction_rang = "Глава отдела"; break;
        case 7: fraction_rang = "Помощник шерифа"; break;
        case 8: fraction_rang = "Шериф"; break;
        case 9: fraction_rang = "Lieutenant II"; break;
        case 10: fraction_rang = "Captain I"; break;
        case 11: fraction_rang = "Captain II"; break;
        case 12: fraction_rang = "Captain III"; break;
        case 13: fraction_rang = "Division Head"; break;
        case 14: fraction_rang = "Assistant Chief"; break;
        case 15: fraction_rang = "Chief of Police"; break;  
              }
    } break;
   case 4: {
      switch(parseInt(fraction_rang)) {
        case 1: fraction_rang = "Помощник фельдшера скорой помощи"; break;
        case 2: fraction_rang = "Фельдшер скорой помощи"; break;
        case 3: fraction_rang = "Интерн"; break;
        case 4: fraction_rang = "Мед.сестра(брат)"; break;
        case 5: fraction_rang = "Врач"; break;
        case 6: fraction_rang = "Заведующий отделением"; break;
        case 7: fraction_rang = "Помощник заведующего"; break;
        case 8: fraction_rang = "Заведующий больницей"; break;
      }
    } break; 
      case 5: {
      switch(parseInt(fraction_rang)) {
        case 1: fraction_rang = "Рядовой-рекрут"; break;
        case 2: fraction_rang = "Рядовой"; break;
        case 3: fraction_rang = "Рядовой 1 класса"; break;
        case 4: fraction_rang = "Капрал"; break;
        case 5: fraction_rang = "Сержант"; break;
        case 6: fraction_rang = "Уорент-офицер 1 класса "; break;
        case 7: fraction_rang = "Уорент-офицер 2 класса "; break;
        case 8: fraction_rang = "Уорент-офицер 3 класса "; break;
        case 9: fraction_rang = "Старший уорент-офицер"; break;
        case 10: fraction_rang = "Второй лейтенант"; break;
        case 11: fraction_rang = "Первый лейтенант"; break;
        case 12: fraction_rang = "Капитан"; break;
        case 13: fraction_rang = "Майор"; break;
        case 14: fraction_rang = "Полковник"; break;
        case 15: fraction_rang = "Генерал-майор"; break;
        case 16: fraction_rang = "Генерал-лейтенант"; break;
        case 17: fraction_rang = "Генерал"; break;      
      }
    } break; 
           case 6: {
      switch(parseInt(fraction_rang)) {
        case 1: fraction_rang = "Пожарный-стажер"; break;
        case 2: fraction_rang = "Пожарный 2 класса"; break;
        case 3: fraction_rang = "Пожарный 1 класса"; break;
        case 4: fraction_rang = "Лейтенант"; break;
        case 5: fraction_rang = "Капитан "; break;
        case 6: fraction_rang = "Командир отряда "; break;
        case 7: fraction_rang = "Глава отдела "; break;
        case 8: fraction_rang = "Помощник главы департамента "; break;
        case 9: fraction_rang = "Глава департамента"; break;      
      }
    } break; 
     case 7: {
      switch(parseInt(fraction_rang)) {
        case 1: fraction_rang = "Стажёр"; break;
        case 2: fraction_rang = "Помощник инструктора"; break;
        case 3: fraction_rang = "Инструктор"; break;
        case 4: fraction_rang = "Старший инструктор"; break;
        case 5: fraction_rang = "Секретарь"; break;
        case 6: fraction_rang = "Заместитель директора "; break;
        case 7: fraction_rang = "Директор "; break;    
      }
    } break; 
       case 8: {
      switch(parseInt(fraction_rang)) {
        case 1: fraction_rang = "Стажёр"; break;
        case 2: fraction_rang = "Агент"; break;
        case 3: fraction_rang = "Старший агент"; break;
        case 4: fraction_rang = "Специальный агент"; break;
        case 5: fraction_rang = "Секретный агент"; break;
        case 6: fraction_rang = "Агент нац.безопасности  "; break;
        case 7: fraction_rang = "Глава отдела "; break;
        case 8: fraction_rang = "Помощник инспектора "; break;
        case 9: fraction_rang = "Инспектор"; break;      
      }
    } break; 
       case 9: {
      switch(parseInt(fraction_rang)) {
        case 1: fraction_rang = "Стажер"; break;
        case 2: fraction_rang = "Надзиратель"; break;
        case 3: fraction_rang = "Старший надзиратель"; break;
        case 4: fraction_rang = "Сержант"; break;
        case 5: fraction_rang = "Лейтенант"; break;
        case 6: fraction_rang = "Капитан "; break;
        case 7: fraction_rang = "Начальник караула "; break;
        case 8: fraction_rang = "Начальник тюрьмы "; break;      
      }
    } break;
    case 10: {
      switch(parseInt(fraction_rang)) {
        case 1: fraction_rang = "Стажер охраны"; break;
        case 2: fraction_rang = "Охранник"; break;
        case 3: fraction_rang = "Начальник охраны"; break;
        case 4: fraction_rang = "Кассир"; break;
        case 5: fraction_rang = "Главный кассир"; break;
        case 6: fraction_rang = "Банкир "; break;
        case 7: fraction_rang = "Заместитель главы банка "; break;
        case 8: fraction_rang = "Глава банка "; break;      
      }
    } break;       
  }
  return fraction_rang;
}
