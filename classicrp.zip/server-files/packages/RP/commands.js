//mp.events.addCommand("Команда", (атрибуты команды через ,) => {
//исполняемый код этой команды
//});
//player.outputChatBox(`text`); - вывод только игроку
//mp.players.broadcast(`text`); - вывод всем игрокам рядом ???

//Чаты
mp.events.addCommand("me", (player, message) => {
    mp.players.broadcast(`${player.name} ${message}`);
});
mp.events.addCommand("o", (player, message) => {
    mp.players.broadcast(`(( ${player.name} [${player.id}]: ${message} ))`);
});
mp.events.addCommand("r", (player, message) => {
    mp.players.broadcast(`[Рация] ${player.name} [${player.id}]: ${message}`);
});
mp.events.addCommand("f", (player, message) => {
    mp.players.broadcast(`[Организация] (( ${player.name} [${player.id}]: ${message} ))`);
});
mp.events.addCommand("a", (player, message) => {
    mp.players.broadcast(`[Админ-чат] ${player.name} [${player.id}]: ${message}`);
});
mp.events.addCommand("s", (player, message) => {
    mp.players.broadcast(`${player.name} [${player.id}] кричит: ${message}`);
});
mp.events.addCommand("w", (player, message) => {
    mp.players.broadcast(`${player.name} [${player.id}] шепчет: ${message}`);
});

//Убрать перед релизом
mp.events.addCommand('veh', (player, _, vehName) => {
    if (vehName && vehName.trim().length > 0) {
        let pos = player.position;
        pos.x += 2;
        //Если игрок в автомобиле - поменять модель
        if (player.customData.vehicle) {
            player.customData.vehicle.repair();
            player.customData.vehicle.position = pos;
            player.customData.vehicle.model = mp.joaat(vehName);
        //Иначе - выдать новый
        } else {
            player.customData.vehicle = mp.vehicles.new(mp.joaat(vehName), pos);
        }
    } else {
        player.outputChatBox(`Ошибка! Синтаксис: /veh [название транспорта]`);
    }
});
mp.events.addCommand('pos', (player) => {
    let pos = player.position;
    let px = parseFloat(pos.x);
    let py = parseFloat(pos.y);
    let pz = parseFloat(pos.z);
    player.outputChatBox(`X: ${px}`);
    player.outputChatBox(`Y: ${py}`);
    player.outputChatBox(`Z: ${pz}`);
});
mp.events.addCommand('tp', (player, _, x, y ,z) => {
    if (!isNaN(parseFloat(x)) && !isNaN(parseFloat(y)) && !isNaN(parseFloat(z)))
        player.position = new mp.Vector3(parseFloat(x),parseFloat(y),parseFloat(z));
    else
        player.outputChatBox(`Ошибка! Синтаксис: /tp [x] [y] [z]`);
});
mp.events.addCommand('fix', (player) => {
    if (player.vehicle)
        player.vehicle.repair();
    else
        player.outputChatBox(`Ошибка, вы не в автомобиле!`);
});
mp.events.addCommand('weapon', (player, _, weaponName) => {
    if (weaponName.trim().length > 0)
        player.giveWeapon(mp.joaat(`weapon_${weaponName}`), 100);
    else
        player.outputChatBox(`Ошибка! Синтаксис: /weapon [weapon_name]`);
});
