"use strict"

const misc = require('../sMisc');
const moneyAPI = require('../Basic/sMoney');
const clothes = require('../Character/sClothes');

const treeMarkersList = [];
let menuShape, dropMarker, dropShape;
const checkPoints = [
    {x: -616.344, y: 5511.083, z: 50.864 },
    {x: -611.316, y: 5516.442, z: 50.324 },
    {x: -606.707, y: 5522.907, z: 50.83 },
    {x: -607.608, y: 5530.482, z: 48.188 },
    {x: -616.371, y: 5533.794, z: 46.868 },
    {x: -622.829, y: 5527.078, z: 47.131 },
    {x: -629.636, y: 5521.292, z: 47.515 },
    {x: -625.256, y: 5515.387, z: 50.568 },
    {x: -617.013, y: 5518.762, z: 53.669 },
];



function createEntities() {
	const mainMenu =  {x: -605.798, y: 5496.809, z: 52.167};
    const posToDrop = {x: -623.481, y: 5503.517, z: 51.205};
	
	// mainMenu
	const menuMarker = mp.markers.new(1, new mp.Vector3(mainMenu.x, mainMenu.y, mainMenu.z - 1), 0.75,
	{
		color: [0, 255, 0, 100],
		visible: true,
	});
	menuShape = mp.colshapes.newSphere(mainMenu.x, mainMenu.y, mainMenu.z, 1);

	const blip = mp.blips.new(527, new mp.Vector3(mainMenu.x, mainMenu.y, mainMenu.z),
	{	
        name: "Holz Sammler Job",
		shortRange: true,
		scale: 0.7,
		color: 17,
	});
	
	//dropMenu
	dropMarker = mp.markers.new(1, new mp.Vector3(posToDrop.x, posToDrop.y, posToDrop.z - 1), 0.75,
	{
		color: [255, 165, 0, 100],
		visible: true,
	});
	dropShape = mp.colshapes.newSphere(posToDrop.x, posToDrop.y, posToDrop.z, 1);

	
	for (let i = 0; i < checkPoints.length; i++) {
		const marker = mp.markers.new(1, new mp.Vector3(checkPoints[i].x, checkPoints[i].y, checkPoints[i].z - 1), 3,
		{
			color: [255, 165, 0, 50],
			visible: false,
        });
        marker.WoodCollectorTree = i;
		treeMarkersList.push(marker);
        const colshape = mp.colshapes.newSphere(checkPoints[i].x, checkPoints[i].y, checkPoints[i].z, 3);
        colshape.WoodCollectorTree = i;
    }
}

function openMainMenu(player) {
    if (player.info.activeJob.name === "Wood Collector") {
        return player.call("cWoodCollectorFinishCef", ['app.loadFinish();']);
    }
    player.call("cWoodCollectorStartCef");
}

function startWork(player) {
    player.info.activeJob = {
        name: "Wood Collector",
        collected: 0,
        activeTree: false,
    };
    createRandomCheckPoint(player);
    player.notify("~g~Du hast den Holz Sammlerjob begonnen!");
    misc.log.debug(`${player.name} started Wood collector job!`);
    dropMarker.showFor(player);
    if (player.model === 1885233650) {
		setWorkingClothesForMan(player);
	}
	else {
		setWorkingClothesForWoman(player);
	}

    function setWorkingClothesForMan(player) {
        player.setProp(0, 14, 0); //Hat
        player.setClothes(11, 78, misc.getRandomInt(0, 15), 0); //Top
        player.setClothes(3, 14, 0, 0);
        player.setClothes(252, 0, 0, 0);
        player.setClothes(4, 0, misc.getRandomInt(0, 15), 0); // Legs
    }
    function setWorkingClothesForWoman(player) {
        player.setProp(0, 14, 0); //Hat
        player.setClothes(11, 78, misc.getRandomInt(0, 7), 0); //Top
        player.setClothes(3, 9, 0, 0);
        player.setClothes(82, 0, 0, 0);
        player.setClothes(4, 1, misc.getRandomInt(0, 15), 0); // Legs
    }
}

function createRandomCheckPoint(player) {
   
    const i = misc.getRandomInt(0, checkPoints.length - 1)
    if (i === player.info.activeJob.activeTree) {
		return createRandomCheckPoint(player);
    }
    hideActiveCheckPoint(player);
    treeMarkersList[i].showFor(player);
    player.info.activeJob.activeTree = i;
    return i;
}

function enteredTreeShape(player) {
    player.stopAnimation();
    player.info.activeJob.collected += misc.getRandomInt(1, 2);
    player.notify(`Du hast ~g~${player.info.activeJob.collected} ~w~Holz in deinem Rucksack!`);
    if (player.info.activeJob.collected < 20) {
        return createRandomCheckPoint(player);
    }
    hideActiveCheckPoint(player);
    player.notify("~g~Dein Rucksack ist voll! Bring es zum Stellplatz!");
}


function hideActiveCheckPoint(player) {
    if (typeof player.info.activeJob.activeTree !== "number") return;
    const i = player.info.activeJob.activeTree;
    treeMarkersList[i].hideFor(player);
    player.info.activeJob.activeTree = false;
}


function enteredDropShape(player) {
    player.stopAnimation();
    if (player.info.activeJob.collected === 0) {
        return player.notify(`Dein Rucksack ist leer!`);
    }
    const earnedMoney = player.info.activeJob.collected * 5;
    moneyAPI.changeMoney(player, earnedMoney);
    player.notify(`Du hast verdient ~g~${earnedMoney}$! ~w~Mach so weiter!`);
    misc.log.debug(`${player.name} earned ${earnedMoney}$!`);
    player.info.activeJob.collected = 0;
    if (!player.info.activeJob.activeTree) {
        createRandomCheckPoint(player);
    }
}

function finishWork(player) {
    hideActiveCheckPoint(player);
    player.info.activeJob = {
        name: false,
    };
    player.notify("~g~Du hast den Job beendet!");
    misc.log.debug(`${player.name} finished Wood collector job!`);
    dropMarker.hideFor(player);
    clothes.loadPlayerClothes(player);
}




mp.events.add(
{
    "playerEnterColshape" : (player, shape) => {
        if (player.vehicle || !player.info) return;
        if (shape === menuShape) {
            player.info.canOpen.WoodCollector = true;
            player.notify(`Benutzen Sie ~b~ E ~s~, um den Job zu betreten`);
        }
        else if (player.info.activeJob.name === "Wood Collector" && shape.WoodCollectorTree === player.info.activeJob.activeTree) {
            player.playAnimation('anim@mp_snowball', 'pickup_snowball', 1, 47);
            setTimeout(enteredTreeShape, 2400, player);
        }
        else if (shape === dropShape && player.info.activeJob.name === "Wood Collector") {
            player.playAnimation('anim@mp_snowball', 'pickup_snowball', 1, 47);
            setTimeout(enteredDropShape, 2400, player);
        }
    },

    "playerExitColshape" : (player, shape) => {
        if (shape === menuShape) {
            return player.info.canOpen.WoodCollector = false;
        }
    },
    
    "sKeys-E" : (player) => {
        if (!player.info || !player.info.loggedIn || !player.info.canOpen.WoodCollector) return;
        if (player.info.activeJob.name && player.info.activeJob.name !== "Wood Collector") {
            return player.nofity("Du arbeitest bereits an einem Job!");
        }
        openMainMenu(player);
    },

    "sWoodCollectorStartWork" : (player) => {
        startWork(player);
    },

    "sWoodCollectorFinishWork" : (player) => {
        finishWork(player);
    },

});






createEntities();