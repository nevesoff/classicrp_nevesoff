# rageserver
Open source rage mp role play server

Hello!
All about this server you can read at:
https://rage.mp/forums/topic/1559-open-source-role-play-server/




# Installation guide:
1. Put all files in your project.
2. Run 'npm install' by cmd in main directory with "server.exe" excutable script.
3. Server using MySQL as a database. So you have to import sql file in to your database. In database management make one like "ragerp".
   Import sql structure file (rpserver.sql) into it.
4. Go into /packages/RP/sMisc.js to edit the way to connect to your database.

THEN ENJOY.
