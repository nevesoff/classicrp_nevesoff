mp.game.blackout = {
    _enabled: false,

    get enabled() {
        return this._enabled;
    },

    set enabled(newState) {
        this._enabled = newState;
        mp.game.graphics.setBlackout(this._enabled);
    }
};

mp.events.add("SetBlackoutState", (newState) => {
    mp.game.blackout.enabled = newState;
});